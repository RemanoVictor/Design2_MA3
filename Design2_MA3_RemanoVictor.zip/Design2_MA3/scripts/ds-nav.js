// ds-ham-nav
let mobileNav= document.querySelector("#hammy");

mobileNav.addEventListener("click", function() {
  
    mobileNav.classList.toggle("is-active");
    
});
